package org.assignments.utils;

/**
 * Created by sunil on 23/12/17.
 */

public class Constants
{
    public static String GITHUBAPI="https://api.github.com/search/users?q=";
}
