package org.assignments.adapters;

import android.app.Activity;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import org.assignments.ModelClasses.Item;
import org.assignments.R;

import java.util.List;


/**
 * Created by sunil on 23/12/17.
 */

public class UsersListAdapter extends RecyclerView.Adapter<UsersListAdapter.CategoryViewHolder> {
    List<Item> data;
    private LayoutInflater inflater; //layout_home variable
    Activity context;
    boolean loading = true;

    /**
     * construcors.....
     *
     * @param context
     * @param data
     */
    public UsersListAdapter(Activity context, List<Item> data) {
        this.context = context; // context
        inflater = LayoutInflater.from(context); // inflater
        this.data = data;
    }

    @Override
    public CategoryViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = inflater.inflate(R.layout.snippet_product, parent, false); // adding the xml to view....
        // return the view...
        return new CategoryViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final CategoryViewHolder holder, final int position) {
        holder.txtuserName.setText(data.get(position).getLogin()+"("+data.get(position).getScore()+")");

        holder.setIsRecyclable(false);
    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    class CategoryViewHolder extends RecyclerView.ViewHolder {
        TextView txtuserName; // title variable
        CardView cardView;
        RelativeLayout lyCategory;


        public CategoryViewHolder(View itemView) {
            super(itemView);
            // finding the ui elements
            txtuserName = (TextView) itemView.findViewById(R.id.txtCategoryName);
            cardView = (CardView) itemView.findViewById(R.id.cardView);
            lyCategory = (RelativeLayout) itemView.findViewById(R.id.lyCategory);
        }

    }

    public void setLoaded() {
        loading = false;
    }

}