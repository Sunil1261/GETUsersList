package org.assignments.interfaces;

/**
 * Created by sunil on 23/12/17.
 */

public interface UsersInterface
{
    public  void getRecipesList(String recipesBeenList);
}
