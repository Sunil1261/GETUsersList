package org.assignments.activity

import android.app.ProgressDialog
import android.databinding.DataBindingUtil
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.support.v7.widget.GridLayoutManager
import android.support.v7.widget.LinearLayoutManager
import android.util.Log
import android.view.View
import android.widget.Toast
import com.google.gson.Gson
import org.assignments.ModelClasses.UsersList
import org.assignments.R
import org.assignments.adapters.UsersListAdapter
import org.assignments.api.UsersListApi
import org.assignments.databinding.ActivityMainBinding
import org.assignments.interfaces.UsersInterface
import android.text.Editable
import android.text.TextWatcher






class UsersActivity : UsersInterface, AppCompatActivity() {
    override fun getRecipesList(recipesBeenList: String?) {
        if (!recipesBeenList!!.isEmpty())
            setAdapter(recipesBeenList)
        Log.v("the recipes list is", "the recipes..." + recipesBeenList)
    }

    internal lateinit var activityMainBinding: ActivityMainBinding
    private var mLinearLayoutManager: LinearLayoutManager? = null
    internal lateinit var  dialog:ProgressDialog

    var page = 1;
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        activityMainBinding = DataBindingUtil.setContentView(this, R.layout.activity_main)
        mLinearLayoutManager = GridLayoutManager(applicationContext, 1)
        dialog= ProgressDialog(this)
        dialog.setMessage("Please wait")
        dialog.setTitle("Loading")
        dialog.setCancelable(false)
        dialog.isIndeterminate = true;

        activityMainBinding.next.setOnClickListener(View.OnClickListener
        {
            page++;
            UsersListApi.recipesListApi(this, this,  activityMainBinding.searchQuery.text.toString(), dialog)

        })
        activityMainBinding.previous.setOnClickListener(View.OnClickListener
        {
            page--;
            UsersListApi.recipesListApi(this, this,  activityMainBinding.searchQuery.text.toString(), dialog)

        })
        if (page == 1) {
            activityMainBinding.previous.visibility = View.GONE
            activityMainBinding.next.visibility = View.GONE
        } else {
            activityMainBinding.previous.visibility = View.VISIBLE
            activityMainBinding.next.visibility = View.VISIBLE
        }

        activityMainBinding.searchQuery.addTextChangedListener(object : TextWatcher {

            override fun afterTextChanged(s: Editable) {}

            override fun beforeTextChanged(s: CharSequence, start: Int,
                                           count: Int, after: Int) {
            }

            override fun onTextChanged(s: CharSequence, start: Int,
                                       before: Int, count: Int) {
                if (s.length != 0)
                    performSearch()
            }
        })

    }
      fun performSearch()
      {
          UsersListApi.recipesListApi(this, this,  activityMainBinding.searchQuery.text.toString(), dialog)

      }

    fun setAdapter(recipes: String?) {
        if (page == 1) {
            activityMainBinding.previous.visibility = View.GONE
        } else {
            activityMainBinding.previous.visibility = View.VISIBLE
        }
        activityMainBinding.next.visibility = View.VISIBLE

        val gson = Gson()
        val recipesList = gson.fromJson<UsersList>(recipes, UsersList::class.java!!)
        val recipesListBeen = recipesList.items;
        if (recipesListBeen.size > 0) {
            var adapter = UsersListAdapter(this, recipesListBeen);
            activityMainBinding.recipesList.setLayoutManager(mLinearLayoutManager)
            activityMainBinding.recipesList.smoothScrollBy(50, 50)
            activityMainBinding.recipesList.setHasFixedSize(true)
            activityMainBinding.recipesList.setAdapter(adapter)
        } else {
            Toast.makeText(this, "User List list is empty", Toast.LENGTH_LONG).show()

        }
    }

}



