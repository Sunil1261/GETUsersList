
package org.assignments.ModelClasses;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class UsersList implements Serializable, Parcelable
{

    @SerializedName("total_count")
    @Expose
    private long totalCount;
    @SerializedName("incomplete_results")
    @Expose
    private boolean incompleteResults;
    @SerializedName("items")
    @Expose
    private List<Item> items = new ArrayList<Item>();
    public final static Creator<UsersList> CREATOR = new Creator<UsersList>() {


        @SuppressWarnings({
            "unchecked"
        })
        public UsersList createFromParcel(Parcel in) {
            return new UsersList(in);
        }

        public UsersList[] newArray(int size) {
            return (new UsersList[size]);
        }

    }
    ;
    private final static long serialVersionUID = 444665094729621453L;

    protected UsersList(Parcel in) {
        this.totalCount = ((long) in.readValue((long.class.getClassLoader())));
        this.incompleteResults = ((boolean) in.readValue((boolean.class.getClassLoader())));
        in.readList(this.items, (org.assignments.ModelClasses.Item.class.getClassLoader()));
    }

    /**
     * No args constructor for use in serialization
     * 
     */
    public UsersList() {
    }

    /**
     * 
     * @param items
     * @param totalCount
     * @param incompleteResults
     */
    public UsersList(long totalCount, boolean incompleteResults, List<Item> items) {
        super();
        this.totalCount = totalCount;
        this.incompleteResults = incompleteResults;
        this.items = items;
    }

    public long getTotalCount() {
        return totalCount;
    }

    public void setTotalCount(long totalCount) {
        this.totalCount = totalCount;
    }

    public UsersList withTotalCount(long totalCount) {
        this.totalCount = totalCount;
        return this;
    }

    public boolean isIncompleteResults() {
        return incompleteResults;
    }

    public void setIncompleteResults(boolean incompleteResults) {
        this.incompleteResults = incompleteResults;
    }

    public UsersList withIncompleteResults(boolean incompleteResults) {
        this.incompleteResults = incompleteResults;
        return this;
    }

    public List<Item> getItems() {
        return items;
    }

    public void setItems(List<Item> items) {
        this.items = items;
    }

    public UsersList withItems(List<Item> items) {
        this.items = items;
        return this;
    }

    public void writeToParcel(Parcel dest, int flags) {
        dest.writeValue(totalCount);
        dest.writeValue(incompleteResults);
        dest.writeList(items);
    }

    public int describeContents() {
        return  0;
    }

}
